import React, { Component } from "react";
import "./SecondSection.css";
import data from "./data.json";
import Square from "./shapes/square.js";
import SideRectangle from "./shapes/siderects";

function SecondSection() {
	return (
		<section className="second-section">
			<Square></Square>

			<h3>{data.SecondSection.subtitle}</h3>
			<p> {data.SecondSection.paragraph}</p>
		</section>
	);
}
export default SecondSection;
