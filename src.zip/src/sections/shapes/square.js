import React, { Component } from "react";
import "./square.css";
import data from "../data.json";

function Square() {
	return (
		<div className="square" style={{ backgroundColor: data.Colors.mainColor }}>
			<div className="black-square">
				{" "}
				<h1>About Me</h1>
			</div>
		</div>
	);
}
export default Square;
