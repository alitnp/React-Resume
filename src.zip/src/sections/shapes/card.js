import React, { Component } from "react";
import "./card.css";
import data from "../data.json";

class Card extends Component {
	render() {
		return (
			<div className="card" style={{ backgroundColor: data.Colors.mainColor }}>
				<div className="hover-card">
					<img src={this.props.logo} alt="" />
					{this.props.name}
				</div>
			</div>
		);
	}
}
export default Card;
