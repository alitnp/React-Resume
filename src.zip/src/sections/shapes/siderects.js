import React, { Component } from "react";
import "./siderects.css";

class SideRectangle extends Component {
	render() {
		return <div className="side-rectangle" style={this.props}></div>;
	}
}
export default SideRectangle;
