import React from "react";
import "./Navigator.css";
import data from "./data.json";
import themeIcon from "./images/theme.png";

class Navigator extends React.Component {
	constructor(props) {
		super(props);
		this.state = { info: data };
	}
	componentDidMount(){
		
	}
	render() {
		return (
			<nav
				className="Navigator"
				style={{
					backgroundColor: data.Colors.mainColor,
				}}
			>
				<img src={themeIcon} className="themeIcon" />
				<div className="navTitles">
					<span
						onClick={() => {
							this.setState((this.state.info.Colors.mainColor = "red"));
						}}
					>
						{data.Navigator.about}
					</span>
					<span>{data.Navigator.skills}</span>
				</div>
			</nav>
		);
	}
}
export default Navigator;
