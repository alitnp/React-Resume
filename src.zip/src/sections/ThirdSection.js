import React, { Component } from "react";
import "./ThirdSection.css";
import data from "./data.json";
import Card from "./shapes/card";

function ThirdSection() {
	return (
		<section className="third-section">
			<h1>Skills</h1>
			<div className="card-holder">
				<Card></Card>
				<Card></Card>
				<Card></Card>
				<Card></Card>
				<Card></Card>

			</div>
		</section>
	);
}
export default ThirdSection;
